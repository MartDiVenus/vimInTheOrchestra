int f(void) { return 0; }
